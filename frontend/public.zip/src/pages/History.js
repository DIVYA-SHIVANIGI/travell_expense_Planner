import React from "react";
import { Link } from "react-router-dom";

export default function History() {
    const historyData = [
        { description: "Groceries", amount: 50, date: "2025-09-18" },
        { description: "Dinner", amount: 30, date: "2025-09-17" },
    ];

    const styles = {
        container: {
            fontFamily: "Arial, sans-serif",
            padding: "40px",
            minHeight: "100vh",
            background: "linear-gradient(135deg,#4facfe,#00f2fe)",
            color: "#fff",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
        },
        table: {
            width: "80%",
            borderCollapse: "collapse",
            marginTop: "20px",
        },
        th: {
            border: "1px solid #ccc",
            padding: "10px",
            backgroundColor: "rgba(0,0,0,0.8)",
            color: "#ccc",
        },
        td: {
            border: "1px solid #ccc",
            padding: "10px",
            textAlign: "center",
            backgroundColor: "rgba(0,0,0,0.6)",
        },
        backLink: {
            color: "#fff",
            textDecoration: "underline",
            marginTop: "20px",
        },
    };

    return (
        <div style={styles.container}>
            <h2>History</h2>
            <table style={styles.table}>
                <thead>
                    <tr>
                        <th style={styles.th}>Description</th>
                        <th style={styles.th}>Amount</th>
                        <th style={styles.th}>Date</th>
                    </tr>
                </thead>
                <tbody>
                    {historyData.map((item, i) => (
                        <tr key={i}>
                            <td style={styles.td}>{item.description}</td>
                            <td style={styles.td}>{item.amount}</td>
                            <td style={styles.td}>{item.date}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <Link to="/dashboard" style={styles.backLink}>⬅ Back</Link>
        </div>
    );
}

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

export default function Expenses() {
    const [groups, setGroups] = useState([]);
    const [selectedGroup, setSelectedGroup] = useState("");
    const [participants, setParticipants] = useState([]);
    const [currentUser] = useState("user1@example.com"); // Removed unused setter
    const [description, setDescription] = useState("");
    const [amount, setAmount] = useState("");
    const [date, setDate] = useState("");
    const [error, setError] = useState("");

    // Fetch groups from backend
    useEffect(() => {
        fetch("http://localhost:8081/groups") // replace with your backend API
            .then((res) => res.json())
            .then((data) => setGroups(data))
            .catch((err) => console.log(err));
    }, []);

    // Fetch participants whenever a group is selected
    useEffect(() => {
        if (selectedGroup) {
            fetch(`http://localhost:8081/groups/${selectedGroup}/participants`) // backend API to get participants for group
                .then((res) => res.json())
                .then((data) => setParticipants(data))
                .catch((err) => console.log(err));
        }
    }, [selectedGroup]);

    const handleSubmit = (e) => {
        e.preventDefault();

        // Check if current user is in the participants
        const isParticipant = participants.some((p) => p.email === currentUser);
        if (!isParticipant) {
            setError("You are not a participant of this group!");
            return;
        }

        setError("");
        alert("Expense added!");
        console.log({ description, amount, date, group: selectedGroup, user: currentUser });

        // Reset form
        setDescription("");
        setAmount("");
        setDate("");
    };

    const styles = {
        container: {
            fontFamily: "'Inter', sans-serif",
            minHeight: "100vh",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            backgroundImage:
                "url('https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1950&q=80')",
            backgroundPosition: "center",
            position: "relative",
            color: "#fff",
        },
        overlay: {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0,0,0,0.65)",
            zIndex: 1,
        },
        formCard: {
            position: "relative",
            zIndex: 2,
            width: "400px",
            padding: "40px",
            borderRadius: "20px",
            background: "rgba(255,255,255,0.05)",
            backdropFilter: "blur(15px)",
            boxShadow: "0 15px 40px rgba(0,0,0,0.7)",
            display: "flex",
            flexDirection: "column",
            gap: "25px",
        },
        heading: {
            fontSize: "2rem",
            fontWeight: 700,
            textAlign: "center",
            color: "#00d4ff",
            marginBottom: "15px",
            letterSpacing: "1px",
        },
        input: {
            padding: "14px",
            borderRadius: "12px",
            border: "none",
            outline: "none",
            fontSize: "16px",
            width: "100%",
            backgroundColor: "rgba(255,255,255,0.1)",
            color: "#fff",
            transition: "all 0.3s ease",
        },
        select: {
            padding: "14px",
            borderRadius: "12px",
            border: "none",
            outline: "none",
            fontSize: "16px",
            width: "100%",
            backgroundColor: "rgba(255,255,255,0.1)",
            color: "#fff",
            transition: "all 0.3s ease",
        },
        button: {
            padding: "14px",
            borderRadius: "12px",
            border: "none",
            fontSize: "16px",
            fontWeight: 700,
            color: "#fff",
            cursor: "pointer",
            background: "linear-gradient(90deg, #00d4ff, #0066ff)",
            transition: "all 0.3s ease",
        },
        buttonHover: {
            transform: "scale(1.05)",
            boxShadow: "0 10px 30px rgba(0,0,0,0.7)",
        },
        backLink: {
            textAlign: "center",
            marginTop: "15px",
            color: "#00d4ff",
            textDecoration: "underline",
        },
        error: {
            color: "#ff4d4f",
            textAlign: "center",
            fontWeight: "bold",
        },
    };

    return (
        <div style={styles.container}>
            <div style={styles.overlay}></div>
            <div style={styles.formCard}>
                <h2 style={styles.heading}>Add Expense</h2>

                <select
                    style={styles.select}
                    value={selectedGroup}
                    onChange={(e) => setSelectedGroup(e.target.value)}
                    required
                >
                    <option value="">Select Group</option>
                    {groups.map((g) => (
                        <option key={g.id} value={g.id}>
                            {g.name}
                        </option>
                    ))}
                </select>

                {selectedGroup && (
                    <form style={{ display: "flex", flexDirection: "column", gap: "20px" }} onSubmit={handleSubmit}>
                        <input
                            type="text"
                            placeholder="Description"
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            style={styles.input}
                            required
                        />
                        <input
                            type="number"
                            placeholder="Amount"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            style={styles.input}
                            required
                        />
                        <input
                            type="date"
                            value={date}
                            onChange={(e) => setDate(e.target.value)}
                            style={styles.input}
                            required
                        />
                        <button
                            type="submit"
                            style={styles.button}
                            onMouseEnter={(e) => Object.assign(e.currentTarget.style, styles.buttonHover)}
                            onMouseLeave={(e) =>
                                Object.assign(e.currentTarget.style, { transform: "scale(1)", boxShadow: "none" })
                            }
                        >
                            Add Expense
                        </button>
                    </form>
                )}

                {error && <p style={styles.error}>{error}</p>}

                <Link to="/dashboard" style={styles.backLink}>
                    ⬅ Back
                </Link>
            </div>
        </div>
    );
}

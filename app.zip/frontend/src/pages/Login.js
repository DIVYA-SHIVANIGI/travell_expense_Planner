import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";

export default function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const res = await axios.post("http://localhost:8081/login", { email, password });
            console.log(res.data); // Optional: save user info in localStorage if needed
            navigate("/dashboard");
        } catch (err) {
            setError(err.response?.data?.message || "Something went wrong");
        }
    };

    const styles = {
        container: {
            fontFamily: "Arial, sans-serif",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            height: "100vh",
            backgroundImage: "url('https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1950&q=80')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            color: "#fff",
        },
        overlay: {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0,0,0,0.6)",
            zIndex: 1,
        },
        formContainer: {
            position: "relative",
            zIndex: 2,
            width: "350px",
            backgroundColor: "rgba(255, 255, 255, 0.1)",
            backdropFilter: "blur(10px)",
            padding: "40px",
            borderRadius: "15px",
            boxShadow: "0 8px 25px rgba(0,0,0,0.5)",
            display: "flex",
            flexDirection: "column",
            gap: "20px",
            textAlign: "center",
        },
        input: {
            padding: "12px",
            borderRadius: "10px",
            border: "none",
            fontSize: "16px",
            outline: "none",
            width: "100%",
            backgroundColor: "rgba(255,255,255,0.2)",
            color: "#fff",
        },
        button: {
            padding: "12px",
            borderRadius: "10px",
            border: "none",
            background: "linear-gradient(90deg, #ff4b2b, #ff416c)",
            fontSize: "16px",
            fontWeight: "bold",
            color: "#fff",
            cursor: "pointer",
            transition: "0.3s",
        },
        buttonHover: {
            background: "linear-gradient(90deg, #ff416c, #ff4b2b)",
        },
        error: {
            color: "#ff6b6b",
            marginTop: "5px",
        },
        link: {
            color: "#fff",
            textDecoration: "underline",
            fontSize: "14px",
        },
    };

    return (
        <div style={styles.container}>
            <div style={styles.overlay}></div>
            <div style={styles.formContainer}>
                <h2>Login</h2>
                <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "15px" }}>
                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        style={styles.input}
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        style={styles.input}
                    />
                    <button type="submit" style={styles.button}>Login</button>
                    {error && <p style={styles.error}>{error}</p>}
                </form>
                <p>
                    Don't have an account? <Link to="/register" style={styles.link}>Register</Link>
                </p>
            </div>
        </div>
    );
}

import React, { useState, useEffect } from "react";

export default function Overview() {
    const [groups, setGroups] = useState([]); // To simulate trips
    const [selectedGroup, setSelectedGroup] = useState("");
    const [groupDetails, setGroupDetails] = useState(null);
    const [participants, setParticipants] = useState([]);
    const [transactions, setTransactions] = useState([]);

    // Fetch all groups for dropdown (like trips)
    useEffect(() => {
        fetch("http://localhost:8081/groups") // Replace with your backend API
            .then((res) => res.json())
            .then((data) => setGroups(data))
            .catch((err) => console.error(err));
    }, []);

    const handleSelect = (e) => {
        setSelectedGroup(e.target.value);
        if (!e.target.value) return;

        // Fetch group details and expenses
        fetch(`http://localhost:8081/groups/${e.target.value}/overview`)
            .then((res) => res.json())
            .then((data) => {
                setGroupDetails({
                    name: data.group_name,
                    estimatedCost: data.estimated_cost,
                    totalContributions: data.total_contributions,
                    splitAmount: data.split_amount,
                });
                setParticipants(data.settlements);
                setTransactions(data.transactions);
            })
            .catch((err) => console.error(err));
    };

    const styles = {
        container: {
            fontFamily: "'Roboto', sans-serif",
            minHeight: "100vh",

            backgroundImage:
                "url('https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1950&q=80')",
            backgroundSize: "cover",
            backgroundPosition: "center",
            padding: "50px 20px",
            color: "#fff",
            position: "relative",
        },
        overlay: {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0,0,0,0.65)",
            zIndex: 1,
        },
        content: {
            position: "relative",
            zIndex: 2,
            maxWidth: "1000px",
            margin: "0 auto",
            backgroundColor: "rgba(255,255,255,0.05)",
            padding: "30px",
            borderRadius: "15px",
            backdropFilter: "blur(10px)",
        },
        title: {
            fontSize: "2.2rem",
            marginBottom: "20px",
            color: "#ffd700",
        },
        label: {
            fontSize: "1.1rem",
            marginBottom: "10px",
            display: "block",
        },
        select: {
            padding: "10px",
            borderRadius: "8px",
            border: "none",
            fontSize: "1rem",
            marginBottom: "20px",
            width: "100%",
            maxWidth: "400px",
        },
        button: {
            padding: "12px 25px",
            fontSize: "1rem",
            fontWeight: "600",
            borderRadius: "8px",
            border: "none",
            cursor: "pointer",
            backgroundColor: "#ffd700",
            color: "#000",
            transition: "all 0.3s ease",
        },
        table: {
            width: "100%",
            borderCollapse: "collapse",
            marginTop: "20px",
        },
        thtd: {
            border: "1px solid #ddd",
            padding: "10px",
            textAlign: "center",
            color: "#fff",
        },
        link: {
            display: "inline-block",
            marginTop: "20px",
            color: "#ffd700",
            textDecoration: "none",
            fontWeight: "600",
        },
    };

    return (
        <div style={styles.container}>
            <div style={styles.overlay}></div>
            <div style={styles.content}>
                <h1 style={styles.title}>Select a Group for Spending Overview</h1>
                <label style={styles.label} htmlFor="group_select">
                    Group:
                </label>
                <select
                    id="group_select"
                    style={styles.select}
                    value={selectedGroup}
                    onChange={handleSelect}
                >
                    <option value="">Select a group</option>
                    {groups.map((g) => (
                        <option key={g.id} value={g.id}>
                            {g.name}
                        </option>
                    ))}
                </select>

                {groupDetails && (
                    <>
                        <h2 style={{ color: "#fff", marginTop: "20px" }}>
                            Overview for: {groupDetails.name}
                        </h2>
                        <p>Estimated Cost: {groupDetails.estimatedCost}</p>
                        <p>Total Contributions: {groupDetails.totalContributions}</p>
                        <p>Average Share per Participant: {groupDetails.splitAmount}</p>

                        <h3>Participant Settlements</h3>
                        <table style={styles.table}>
                            <thead>
                                <tr>
                                    <th style={styles.thtd}>Participant</th>
                                    <th style={styles.thtd}>Paid</th>
                                    <th style={styles.thtd}>Owes (Average Share)</th>
                                    <th style={styles.thtd}>Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                {participants.map((p, i) => {
                                    const balance = p.amount_paid - p.split_amount;
                                    return (
                                        <tr key={i}>
                                            <td style={styles.thtd}>{p.username}</td>
                                            <td style={styles.thtd}>{p.amount_paid.toFixed(2)}</td>
                                            <td style={styles.thtd}>{p.split_amount.toFixed(2)}</td>
                                            <td style={styles.thtd}>
                                                {balance.toFixed(2)} {balance < 0 ? "(owes)" : "(owed)"}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>

                        <h3 style={{ marginTop: "30px" }}>Transactions</h3>
                        <table style={styles.table}>
                            <thead>
                                <tr>
                                    <th style={styles.thtd}>From</th>
                                    <th style={styles.thtd}>To</th>
                                    <th style={styles.thtd}>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                {transactions.map((t, i) => (
                                    <tr key={i}>
                                        <td style={styles.thtd}>{t.from}</td>
                                        <td style={styles.thtd}>{t.to}</td>
                                        <td style={styles.thtd}>{t.amount.toFixed(2)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>

                        <a href="/overview" style={styles.link}>
                            &larr; Back
                        </a>
                    </>
                )}
            </div>
        </div>
    );
}

const express = require('express');
const cors = require('cors');
const db = require('./config/db');
const app = express();

app.use(cors());
app.use(express.json());

// Example GET endpoint for expenses
app.get('/expenses', (req, res) => {
  db.query('SELECT * FROM expenses', (err, result) => {
    if (err) return res.status(500).json({error: err});
    res.json(result);
  });
});

// Example POST endpoint for new expense
app.post('/expenses', (req, res) => {
  const { name, amount } = req.body;
  db.query('INSERT INTO expenses (name, amount) VALUES (?, ?)', [name, amount], (err, result) => {
    if (err) return res.status(500).json({error: err});
    res.json({message: "Expense added!"});
  });
});

app.listen(5000, () => console.log("Server started on port 5000"));

package com.lucy.split_mate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SplitMateBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(SplitMateBackendApplication.class, args);
    }
}

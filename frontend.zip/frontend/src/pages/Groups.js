import React, { useState, useEffect } from "react";

export default function Group() {
    const [groupName, setGroupName] = useState("");
    const [location, setLocation] = useState("");
    const [participants, setParticipants] = useState([]);
    const [selectedParticipants, setSelectedParticipants] = useState([]);
    const [message, setMessage] = useState("");

    // Fetch all registered users to add to group
    useEffect(() => {
        fetch("http://localhost:8081/users") // Replace with your backend API
            .then((res) => res.json())
            .then((data) => setParticipants(data))
            .catch((err) => console.error(err));
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!groupName || !location || selectedParticipants.length === 0) {
            setMessage("Please fill all fields and select participants!");
            return;
        }

        // Prepare payload
        const payload = {
            name: groupName,
            location: location,
            participants: selectedParticipants,
        };

        fetch("http://localhost:8081/groups", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(payload),
        })
            .then((res) => res.json())
            .then((data) => {
                setMessage("Group created successfully!");
                setGroupName("");
                setLocation("");
                setSelectedParticipants([]);
            })
            .catch((err) => {
                console.error(err);
                setMessage("Error creating group. Try again.");
            });
    };

    const styles = {
        container: {
            fontFamily: "'Roboto', sans-serif",
            minHeight: "100vh",
            backgroundImage: "url('https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1950&q=80')",

            backgroundSize: "cover",
            backgroundPosition: "center",
            padding: "50px 20px",
            color: "#fff",
            position: "relative",
        },
        overlay: {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0,0,0,0.65)",
            zIndex: 1,
        },
        content: {
            position: "relative",
            zIndex: 2,
            maxWidth: "600px",
            margin: "0 auto",
            backgroundColor: "rgba(255,255,255,0.05)",
            padding: "30px",
            borderRadius: "15px",
            backdropFilter: "blur(10px)",
        },
        title: {
            fontSize: "2rem",
            marginBottom: "20px",
            color: "#ffd700",
            textAlign: "center",
        },
        label: {
            display: "block",
            marginBottom: "8px",
            fontWeight: "600",
            fontSize: "1rem",
        },
        input: {
            width: "100%",
            padding: "10px",
            borderRadius: "8px",
            border: "none",
            marginBottom: "20px",
            fontSize: "1rem",
        },
        select: {
            width: "100%",
            padding: "10px",
            borderRadius: "8px",
            border: "none",
            marginBottom: "20px",
            fontSize: "1rem",
            height: "120px",
        },
        button: {
            width: "100%",
            padding: "12px",
            fontSize: "1rem",
            fontWeight: "600",
            borderRadius: "8px",
            border: "none",
            cursor: "pointer",
            backgroundColor: "#ffd700",
            color: "#000",
            transition: "all 0.3s ease",
        },
        message: {
            textAlign: "center",
            marginTop: "15px",
            color: "#00ffcc",
            fontWeight: "600",
        },
    };

    return (
        <div style={styles.container}>
            <div style={styles.overlay}></div>
            <div style={styles.content}>
                <h1 style={styles.title}>Create a New Group</h1>
                <form onSubmit={handleSubmit}>
                    <label style={styles.label}>Group Name:</label>
                    <input
                        style={styles.input}
                        type="text"
                        placeholder="Enter group name"
                        value={groupName}
                        onChange={(e) => setGroupName(e.target.value)}
                    />

                    <label style={styles.label}>Location / Description:</label>
                    <input
                        style={styles.input}
                        type="text"
                        placeholder="Where did you go?"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                    />

                    <label style={styles.label}>Select Participants:</label>
                    <select
                        style={styles.select}
                        multiple
                        value={selectedParticipants}
                        onChange={(e) =>
                            setSelectedParticipants(
                                Array.from(e.target.selectedOptions, (option) => option.value)
                            )
                        }
                    >
                        {participants.map((p) => (
                            <option key={p.id} value={p.id}>
                                {p.name} ({p.email})
                            </option>
                        ))}
                    </select>

                    <button style={styles.button} type="submit">
                        Create Group
                    </button>
                    {message && <p style={styles.message}>{message}</p>}
                </form>
            </div>
        </div>
    );
}

import React from "react";
import { Link } from "react-router-dom";

export default function Dashboard() {
    const styles = {
        container: {
            fontFamily: "'Montserrat', sans-serif",
            minHeight: "100vh",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            backgroundSize: "cover",
            backgroundImage: "url('https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=1950&q=80')",
            backgroundPosition: "center",
            position: "relative",
            color: "#fff",
        },
        overlay: {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0, 0, 0, 0.6)",
            zIndex: 1,
        },
        title: {
            position: "relative",
            zIndex: 2,
            fontSize: "3rem",
            fontWeight: 800,
            marginBottom: "50px",
            textAlign: "center",
            color: "#ffd700",
            fontFamily: "'Poppins', sans-serif",
            letterSpacing: "1px",
            textShadow: "2px 2px 15px rgba(0,0,0,0.7)",
        }

        ,
        buttonContainer: {
            position: "relative",
            zIndex: 2,
            display: "flex",
            flexDirection: "column",
            gap: "25px",
            width: "280px",
        },
        button: {
            padding: "18px 25px",
            fontSize: "1.3rem",
            fontWeight: "600",
            borderRadius: "12px",
            border: "none",
            cursor: "pointer",
            textAlign: "center",
            color: "#fff",
            backgroundColor: "rgba(255, 217, 0, 0.67)",
            backdropFilter: "blur(12px)",
            boxShadow: "0 6px 25px rgba(0,0,0,0.5)",
            transition: "all 0.3s ease",
            textDecoration: "none",
        },
    };

    const handleHover = (e) => {
        e.currentTarget.style.transform = "scale(1.05)";
        e.currentTarget.style.backgroundColor = "rgba(255, 215, 0, 0.35)";
        e.currentTarget.style.boxShadow = "0 10px 35px rgba(0,0,0,0.7)";
    };

    const handleLeave = (e) => {
        e.currentTarget.style.transform = "scale(1)";
        e.currentTarget.style.backgroundColor = "rgba(255, 215, 0, 0.15)";
        e.currentTarget.style.boxShadow = "0 6px 25px rgba(0,0,0,0.5)";
    };

    return (
        <div style={styles.container}>
            <div style={styles.overlay}></div>
            <h1 style={styles.title}>Smart Group Expense Splitter</h1>
            <div style={styles.buttonContainer}>

                <Link
                    to="/groups"
                    style={styles.button}
                    onMouseEnter={handleHover}
                    onMouseLeave={handleLeave}
                >
                    Create Group 👥
                </Link>
                <Link
                    to="/expenses"
                    style={styles.button}
                    onMouseEnter={handleHover}
                    onMouseLeave={handleLeave}
                >
                    Add Expense 💰
                </Link>
                <Link
                    to="/overview"
                    style={styles.button}
                    onMouseEnter={handleHover}
                    onMouseLeave={handleLeave}
                >
                    Overview 📊
                </Link>
                <Link
                    to="/history"
                    style={styles.button}
                    onMouseEnter={handleHover}
                    onMouseLeave={handleLeave}
                >
                    History 🕒
                </Link>
            </div>
        </div>
    );
}
